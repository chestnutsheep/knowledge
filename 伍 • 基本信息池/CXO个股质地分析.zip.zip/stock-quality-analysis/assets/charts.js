(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var accent3 = style.getPropertyValue('--accent3').trim();
  var accent4 = style.getPropertyValue('--accent4').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  var stockNames = ['药明康德', '百普赛斯', '成都先导', '义翘神州', '药石科技', '诺唯赞', '美迪西', '近岸蛋白'];

  // Color palette: green for profitable, red for loss
  function getBarColors(values, threshold) {
    return values.map(function(v) {
      if (v >= threshold) return accent3;
      if (v < 0) return accent2;
      return accent;
    });
  }

  // ===== Chart 1: Revenue =====
  var chartRevenue = echarts.init(document.getElementById('chart-revenue'), null, { renderer: 'svg' });
  var revenueData = [454.60, 8.38, 5.26, 7.00, 19.74, 13.78, 11.63, 1.46];
  chartRevenue.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      appendToBody: true,
      formatter: function(params) {
        return params[0].name + '<br/>2025营收: <b>' + params[0].value + '</b> 亿元';
      }
    },
    grid: { left: 60, right: 30, top: 30, bottom: 70 },
    xAxis: {
      type: 'category',
      data: stockNames,
      axisLabel: { color: muted, fontSize: 11, rotate: 30, interval: 0 },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '亿元',
      nameTextStyle: { color: muted, fontSize: 11 },
      axisLabel: { color: muted, fontSize: 11 },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLine: { show: false }
    },
    series: [{
      type: 'bar',
      data: revenueData.map(function(v, i) {
        return {
          value: v,
          itemStyle: { color: i === 0 ? accent : (accent + 'cc'), borderRadius: [4, 4, 0, 0] }
        };
      }),
      barWidth: '50%',
      label: {
        show: true,
        position: 'top',
        color: ink,
        fontSize: 11,
        fontWeight: 600,
        formatter: function(p) {
          return p.value >= 100 ? p.value.toFixed(0) : p.value.toFixed(1);
        }
      }
    }]
  });
  window.addEventListener('resize', function() { chartRevenue.resize(); });

  // ===== Chart 2: Gross Margin =====
  var chartMargin = echarts.init(document.getElementById('chart-margin'), null, { renderer: 'svg' });
  var marginData = [47.63, 91.16, 54.22, 75.00, 30.81, 69.54, 17.35, 67.12];
  chartMargin.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      appendToBody: true,
      formatter: function(params) {
        return params[0].name + '<br/>毛利率: <b>' + params[0].value + '%</b>';
      }
    },
    grid: { left: 60, right: 30, top: 30, bottom: 70 },
    xAxis: {
      type: 'category',
      data: stockNames,
      axisLabel: { color: muted, fontSize: 11, rotate: 30, interval: 0 },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '%',
      nameTextStyle: { color: muted, fontSize: 11 },
      max: 100,
      axisLabel: { color: muted, fontSize: 11, formatter: '{value}%' },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLine: { show: false }
    },
    series: [{
      type: 'bar',
      data: marginData.map(function(v, i) {
        var color = v >= 70 ? accent3 : (v >= 50 ? accent : (v >= 30 ? accent4 : accent2));
        return { value: v, itemStyle: { color: color, borderRadius: [4, 4, 0, 0] } };
      }),
      barWidth: '50%',
      label: {
        show: true,
        position: 'top',
        color: ink,
        fontSize: 11,
        fontWeight: 600,
        formatter: '{c}%'
      }
    }]
  });
  window.addEventListener('resize', function() { chartMargin.resize(); });

  // ===== Chart 3: ROE =====
  var chartRoe = echarts.init(document.getElementById('chart-roe'), null, { renderer: 'svg' });
  var roeData = [28.56, 6.31, 7.70, 2.78, 4.17, -0.43, -8.26, -3.76];
  chartRoe.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      appendToBody: true,
      formatter: function(params) {
        return params[0].name + '<br/>ROE: <b>' + params[0].value + '%</b>';
      }
    },
    grid: { left: 60, right: 30, top: 30, bottom: 70 },
    xAxis: {
      type: 'category',
      data: stockNames,
      axisLabel: { color: muted, fontSize: 11, rotate: 30, interval: 0 },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '%',
      nameTextStyle: { color: muted, fontSize: 11 },
      axisLabel: { color: muted, fontSize: 11, formatter: '{value}%' },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLine: { show: false }
    },
    series: [{
      type: 'bar',
      data: roeData.map(function(v) {
        var color = v >= 10 ? accent3 : (v >= 0 ? accent : accent2);
        return { value: v, itemStyle: { color: color, borderRadius: v >= 0 ? [4, 4, 0, 0] : [0, 0, 4, 4] } };
      }),
      barWidth: '50%',
      label: {
        show: true,
        position: function(p) { return p.value >= 0 ? 'top' : 'bottom'; },
        color: ink,
        fontSize: 11,
        fontWeight: 600,
        formatter: '{c}%'
      },
      markLine: {
        silent: true,
        symbol: 'none',
        lineStyle: { color: muted, type: 'dashed', width: 1 },
        data: [{ yAxis: 0 }],
        label: { show: false }
      }
    }]
  });
  window.addEventListener('resize', function() { chartRoe.resize(); });

  // ===== Chart 4: Valuation Scatter =====
  var chartValuation = echarts.init(document.getElementById('chart-valuation'), null, { renderer: 'svg' });
  // Only profitable stocks have PE; loss-making stocks shown at PE=0 with note
  var valuationData = [
    { name: '药明康德', value: [22, 5.74, 4745], profit: true },
    { name: '百普赛斯', value: [80, 5.22, 138], profit: true },
    { name: '成都先导', value: [123, 10.10, 151], profit: true },
    { name: '义翘神州', value: [109, 2.74, 145], profit: true },
    { name: '药石科技', value: [63, 5.50, 116], profit: true },
    { name: '诺唯赞', value: [0, 3.05, 122], profit: false },
    { name: '美迪西', value: [0, 4.57, 142], profit: false },
    { name: '近岸蛋白', value: [0, 2.22, 45], profit: false }
  ];

  var profitData = valuationData.filter(function(d) { return d.profit; }).map(function(d) {
    return { name: d.name, value: d.value };
  });
  var lossData = valuationData.filter(function(d) { return !d.profit; }).map(function(d) {
    return { name: d.name, value: d.value };
  });

  chartValuation.setOption({
    animation: false,
    tooltip: {
      trigger: 'item',
      appendToBody: true,
      formatter: function(p) {
        var pe = p.data.value[0];
        var pb = p.data.value[1];
        var mcap = p.data.value[2];
        var peStr = pe > 0 ? pe + '倍' : 'N/A (亏损)';
        return '<b>' + p.data.name + '</b><br/>PE-TTM: ' + peStr + '<br/>PB: ' + pb + '倍<br/>市值: ' + mcap + '亿';
      }
    },
    legend: {
      data: ['盈利公司', '亏损公司'],
      bottom: 5,
      textStyle: { color: muted, fontSize: 12 }
    },
    grid: { left: 60, right: 40, top: 30, bottom: 60 },
    xAxis: {
      type: 'value',
      name: 'PE-TTM (倍)',
      nameLocation: 'middle',
      nameGap: 32,
      nameTextStyle: { color: muted, fontSize: 11 },
      axisLabel: { color: muted, fontSize: 11 },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLine: { lineStyle: { color: rule } },
      max: 140
    },
    yAxis: {
      type: 'value',
      name: 'PB (倍)',
      nameLocation: 'middle',
      nameGap: 40,
      nameTextStyle: { color: muted, fontSize: 11 },
      axisLabel: { color: muted, fontSize: 11 },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLine: { lineStyle: { color: rule } },
      max: 12
    },
    series: [
      {
        name: '盈利公司',
        type: 'scatter',
        data: profitData,
        symbolSize: function(data) {
          return Math.sqrt(data[2]) / 2 + 14;
        },
        itemStyle: {
          color: accent + 'cc',
          borderColor: accent,
          borderWidth: 2
        },
        label: {
          show: true,
          formatter: '{b}',
          position: 'top',
          color: ink,
          fontSize: 11,
          fontWeight: 600
        }
      },
      {
        name: '亏损公司',
        type: 'scatter',
        data: lossData,
        symbolSize: function(data) {
          return Math.sqrt(data[2]) / 2 + 14;
        },
        itemStyle: {
          color: accent2 + '66',
          borderColor: accent2,
          borderWidth: 2
        },
        label: {
          show: true,
          formatter: '{b}',
          position: 'top',
          color: ink,
          fontSize: 11,
          fontWeight: 600
        },
        markArea: {
          silent: true,
          itemStyle: { color: accent2 + '08' },
          data: [[{ xAxis: -5 }, { xAxis: 10 }]]
        }
      }
    ]
  });
  window.addEventListener('resize', function() { chartValuation.resize(); });

  // ===== Chart 5: Quality Radar =====
  var chartRadar = echarts.init(document.getElementById('chart-radar'), null, { renderer: 'svg' });
  chartRadar.setOption({
    animation: false,
    tooltip: { trigger: 'item', appendToBody: true },
    legend: {
      data: ['药明康德', '百普赛斯', '成都先导', '义翘神州', '药石科技', '诺唯赞', '美迪西', '近岸蛋白'],
      bottom: 0,
      textStyle: { color: muted, fontSize: 10 },
      type: 'scroll',
      pageIconColor: accent,
      pageTextStyle: { color: muted }
    },
    radar: {
      indicator: [
        { name: '盈利能力', max: 10 },
        { name: '成长性', max: 10 },
        { name: '竞争壁垒', max: 10 },
        { name: '估值合理性', max: 10 },
        { name: '财务健康', max: 10 }
      ],
      center: ['50%', '48%'],
      radius: '62%',
      axisName: { color: ink, fontSize: 12, fontWeight: 600 },
      splitArea: { areaStyle: { color: [bg2, bg2 + 'cc'] } },
      splitLine: { lineStyle: { color: rule } },
      axisLine: { lineStyle: { color: rule } }
    },
    series: [{
      type: 'radar',
      data: [
        { name: '药明康德', value: [9.5, 8.5, 9.5, 9.0, 9.0], lineStyle: { color: accent, width: 2 }, areaStyle: { color: accent + '20' }, itemStyle: { color: accent } },
        { name: '百普赛斯', value: [8.0, 9.0, 8.5, 6.0, 8.0], lineStyle: { color: accent3, width: 2 }, areaStyle: { color: accent3 + '20' }, itemStyle: { color: accent3 } },
        { name: '成都先导', value: [7.0, 9.0, 8.5, 4.0, 7.5], lineStyle: { color: '#7c3aed', width: 2 }, areaStyle: { color: '#7c3aed20' }, itemStyle: { color: '#7c3aed' } },
        { name: '义翘神州', value: [6.0, 7.0, 7.5, 5.0, 7.0], lineStyle: { color: '#0891b2', width: 2 }, areaStyle: { color: '#0891b220' }, itemStyle: { color: '#0891b2' } },
        { name: '药石科技', value: [5.0, 6.0, 7.0, 5.5, 7.0], lineStyle: { color: '#b45309', width: 2 }, areaStyle: { color: '#b4530920' }, itemStyle: { color: '#b45309' } },
        { name: '诺唯赞', value: [3.5, 5.5, 7.0, 6.0, 6.0], lineStyle: { color: '#6b7280', width: 2 }, areaStyle: { color: '#6b728020' }, itemStyle: { color: '#6b7280' } },
        { name: '美迪西', value: [2.5, 6.0, 5.0, 5.0, 4.0], lineStyle: { color: accent2, width: 2 }, areaStyle: { color: accent2 + '20' }, itemStyle: { color: accent2 } },
        { name: '近岸蛋白', value: [2.0, 5.0, 5.5, 6.5, 3.5], lineStyle: { color: '#9ca3af', width: 2 }, areaStyle: { color: '#9ca3af20' }, itemStyle: { color: '#9ca3af' } }
      ]
    }]
  });
  window.addEventListener('resize', function() { chartRadar.resize(); });

})();
